# process_behaviorconstraints.py - Handles behavior constraints
#
# Copyright (C) 2011 University of Southern California.
# All rights reserved.
#
# Redistribution and use in source and binary forms are permitted
# provided that the above copyright notice and this paragraph are
# duplicated in all such forms and that any documentation, advertising
# materials, and other materials related to such distribution and use
# acknowledge that the software was developed by the University of
# Southern California, Information Sciences Institute.  The name of the
# University may not be used to endorse or promote products derived from
# this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED
# WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF
# MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#
# Author: Arun Viswanathan (aviswana@usc.edu)
#------------------------------------------------------------------------------

import framework.common.sqlutils as sqlutils
from framework.objects.eventgroup import EventGroup
from framework.objects.behaviorinstancelist import BehaviorInstanceList
from framework.objects.behaviorinstance import BehaviorInstance
from framework.common.errordefs import SymbolTableError
from framework.common.errordefs import SyntaxError, AbortCondition
from framework.common.errordefs import ConstraintError,ModelProcessingError

class BehaviorConstraintProcessor:
    """
        Provides a behavior abstraction for the model processing algorithm.
    """
       
    def __init__(self, logger, datahandle, statehandle, stateproc, modelproc):
        self.sh      = statehandle
        self.dh      = datahandle
        self.logger  = logger
        self.state_proc = stateproc
        self.model_proc  = modelproc
            

    def apply_behavior_constraints(self, callerobj, constraints, instances):
        """
            Apply behavior constraints for each instance in the input list
            of instances and return a list of behavior instances satisfying the 
            constraint.
        """
        
        if __debug__: 
            self.logger.info("Applying behavior constraints %s to behavior %s" % \
                                                     (constraints,
                                                      callerobj.get_name()))
        
        
        (cname, relop, cval, cqual) = constraints.get_constraint()
        if __debug__: 
            self.logger.debug("Constraint Fetched : %s %s %s %s " % \
                         (cname, relop, cval, cqual))
        newinstances = BehaviorInstanceList()
        self.sh.flush_cache()
        if(len(instances[0]) > 0):
            self.sh.prefetch_records(instances)
        else:
            return newinstances

        try:
            if(cname == "bcount"):
                newinstances = self.check_bcount(instances, cval, relop, cqual)
            elif(cname == "icount"):
                newinstances = self.check_icount(instances, cval, relop, cqual)
            elif(cname == "at"):
                newinstances = self.check_at(instances, cval, relop, cqual)
            elif(cname == "end"):
                newinstances = self.check_end(instances, cval, relop, cqual)
            elif(cname == "duration"):
                newinstances = self.check_duration(instances, cval, relop, cqual)
            elif(cname == "rate"):
                newinstances = self.check_rate(instances, cval, relop, cqual)
            elif(cname == "_limit"):
                newinstances = self.apply__limit(instances, cval, relop, cqual)
            elif(cname == "_eventno"):
                newinstances = self.apply__eventno(instances, cval, relop, cqual)
            else:
                raise Exception("Constraint '%s' not recognized!" % (cname))
        except SyntaxError, ConstraintError:
            raise ModelProcessingError
        except SymbolTableError:
            raise AbortCondition

        return newinstances
    
    
    def build_constraint_expr(self, relop, expval, actualval):
        expr = ""
        if(isinstance(expval,tuple)):
            lower,upper = expval
            expr = "%s >= %s and %s <= %s" % (actualval, lower, actualval, upper)
            if(relop != "="):
                raise Exception(" Constraint expression cannot be related to a range via '%s'" %(relop))    
        else:
            if (relop == '='):
                relop = "=="
            expr = "%s %s %s" % (actualval, relop, expval)
        return expr


    def check_icount(self, instances, cval, relop, cqual):
        expr = self.build_constraint_expr(relop, cval, len(instances))
        val = eval(expr)
        if __debug__: 
            self.logger.debug("Check Instance Count : %s %s" % (expr, val))
        return val

    def apply__limit(self, instances, cval, relop, cqual):
        if(relop != "="):
            raise Exception("'_limit' can be followed only by '=' ")        
        try: 
            cval = int(cval)
        except:                
            raise Exception("'_limit' keyword followed by invalid value %s" %(cval))
        
        if (cval < 0):
            raise Exception("'_limit' keyword followed by a negative value %s" %(cval))
        
        for r in instances:
            if(not isinstance(r,BehaviorInstance)):
                raise Exception("Invalid type of instance for _limit!")
            
            insts = r.get_contents()
            newinstlist = BehaviorInstanceList(insts[:cval])
            return newinstlist           
            
    def apply__eventno(self, instances, cval, relop, cqual):
            
        lower = None
        upper = None
        if(isinstance(cval,tuple)): 
            lower,upper = cval
            if(relop != "="):
                raise Exception("'_eventno' cannot be related to a range via '%s'" %(relop))    
        else:
            try:
                cval = int(cval)
            except:
                raise Exception("'_eventno' followed by invalid value '%s'" %(cval))            
            if(relop == "="):
                lower = cval
                upper = cval
            elif (relop == ">"):                
                lower = cval + 1
            elif (relop == ">="):                
                lower = cval
            elif (relop == "<="):                
                upper = cval
            elif (relop == "<"):                
                upper = (cval - 1) if ((cval - 1) >0) else 1 
            else:
                raise Exception("Unsupported operator %s for '_eventno' " %(relop))    
        
        for r in instances:
            if(not isinstance(r,BehaviorInstance)):
                raise Exception("Invalid type of instance for _eventno!")        
                        
            newinstlist = BehaviorInstanceList()
            insts = r.get_contents()
        
            lower = 0 if lower == None else lower
            upper = r.get_last_id() if upper == None else upper
            # Note that for eventgroups the get_id() always returns the 
            # last id of the last event in the group
            
            if __debug__:
                self.logger.info("Lower eventno : %s Upper eventno : %s " %\
                                 (lower,upper))
            for n in insts:
                id = n.get_id()
                if((id >= lower) and (id <= upper)):
                    newinstlist.insert(n) 
            return newinstlist
    
    
    def check_bcount(self, instances, cval, relop, cqual):
        newinstances = BehaviorInstanceList([], bobject=instances.get_behavior())
        
        for r in instances:
            
            if(not isinstance(r,BehaviorInstance)):
                raise Exception("Invalid type of instance found while checking bcount!")
            rid = r.get_id()
            bcount = r.get_bcount() 
            insts = r.get_contents()
            dep_ptr = r.get_dependee()
            b_ptr = r.get_behavior()

            expr = self.build_constraint_expr(relop, cval, bcount)
            val = eval(expr)
            if __debug__: 
                self.logger.info("Check Event Count : %s %s" % (expr, val))

            if(val):
                updatelist = insts
#                # If the relop is >= return only minimum number of 
#                # events that are required to be matched. This is required
#                # to process the later time constraints like within and after 
#                # correctly. 
#                # If this is not done, constraints like within will result in  
#                # wrong results when it tries to compute using the duration of 
#                # the complete returned set
#                if((relop == '>==')):
#                    hindex = int(cval)
#                    if (hindex < 0): hindex = 0
#                    updatelist = insts[:hindex]
#                    if __debug__: 
#                        self.logger.debug("Created new list: %s" % (updatelist))
                
                eg = EventGroup(updatelist)
                eg.set_behavior(b_ptr)
                eg.set_dependee(dep_ptr)
                newinstances.insert(eg)
        
        return newinstances

