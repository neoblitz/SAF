# attributes.py 
#
# Copyright (C) 2011 University of Southern California.
# All rights reserved.
#
# Redistribution and use in source and binary forms are permitted
# provided that the above copyright notice and this paragraph are
# duplicated in all such forms and that any documentation, advertising
# materials, and other materials related to such distribution and use
# acknowledge that the software was developed by the University of
# Southern California, Information Sciences Institute.  The name of the
# University may not be used to endorse or promote products derived from
# this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED
# WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF
# MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#
# Author: Arun Viswanathan (aviswana@usc.edu)
#------------------------------------------------------------------------------
from datetime import datetime
from datetime import tzinfo, timedelta, datetime

class Attributes:

    default_attrs = [('eventno', 'integer primary key autoincrement'), 
                     ('timestamp','integer'),
                     ('timestampusec','integer'), 
                     ('eventtype','text'), 
                     ('origin','text')]
        
    def __init__(self):
        self.attrlist = []
        self.attrvaluehash = {}
        self.attrtypehash = {}
        for a, t in self.default_attrs:
            self.add(a, t)
        self.timeobj = self.init_time()
        
    def init_time(self):
        timeobj = {}
        d = datetime.now()
        timeobj['year'] = d.year
        timeobj['month'] = 0
        timeobj['day'] = 0
        timeobj['hour'] = 0
        timeobj['min'] = 0
        timeobj['sec'] = 0
        timeobj['microsec'] = 0
        timeobj['tzinfo'] = None
        return timeobj
        
    def get_timeobj(self):
        return self.timeobj
    
    def add(self, attr, attrtype):
        if(attr not in self.attrlist):
            self.attrlist.append(attr)
            self.attrtypehash[attr] = attrtype
            self.attrvaluehash[attr] = None
   
    def set(self, attr, value):
         self.attrvaluehash[attr] = value
 
    def set_eventno(self, value):
        if(value):
            self.set('eventno', value)
    
    def set_eventtype(self, value):
         self.set('eventtype', value)

    def set_origin(self, value):
         self.set('origin', value)

    def set_timestamp(self, (ts,tsusec)):
         self.set('timestamp', ts)
         self.set('timestampusec', tsusec)
    
    def get(self, attr):
        if(attr not in self.attrlist):
            raise Exception("Invalid attribute '%s' specified"%(attr))
        else:
            return self.attrvaluehash[attr]

    def get_all_attrs(self):
        return self.attrlist

    def get_unique_attrs(self):
        return list(set(self.attrlist)-set(self.default_attrs))
    
    def get_attr_type_tuples(self):
        tuplist = []
        for a in self.attrlist:
            tup = (a, self.attrtypehash.get(a))
            tuplist.append(tup)
        return tuplist  
    
    def __repr__(self):
        pstrlist = []
        for a in self.attrlist:
            pstrlist.append('%s=%s'%(a, self.attrvaluehash.get(a)))
        return ",".join(pstrlist)