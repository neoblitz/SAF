# plugin_mysql.py - Plugin for MySql logs
#
# Copyright (C) 2011 University of Southern California.
# All rights reserved.
#
# Redistribution and use in source and binary forms are permitted
# provided that the above copyright notice and this paragraph are
# duplicated in all such forms and that any documentation, advertising
# materials, and other materials related to such distribution and use
# acknowledge that the software was developed by the University of
# Southern California, Information Sciences Institute.  The name of the
# University may not be used to endorse or promote products derived from
# this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED
# WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF
# MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#
# Author: Arun Viswanathan (aviswana@usc.edu)
#------------------------------------------------------------------------------
from plugin_base import BasicPlugin
from attributes import Attributes
import commonterms

class MySqlPlugin(BasicPlugin):

    def init_plugin_attrs(self):
        self.attrs = Attributes()
        self.attrs.add('loglevel', 'text')
        self.attrs.add('charstring', 'text')
        return self.attrs
    
    def get_record_attrs(self, record):
        return self.attrs
    
    def get_eventtype(self, record=None):
        return "MYSQL"
    
    def get_production(self):
        return "mysqlrec"
  
    def get_ebnf(self):
        return self.ebnf

#11/Sep/2010:20:35:05:138 [CRITICAL] ./mysqld: Shutdown complete

    ebnf = r'''#Comment
mysqlrec := record
record    := tstamp, (':'/','), [0-9]+,  ts, '[',loglevel, ']', ts, charstring
tstamp    := day, '/', month, '/', year, ':',hour, ':', min, ':', sec, (ts, tzone)?  
loglevel := [A-Za-z]+
charstring := ts, -"\n"*
ts        :=  [ \t]*
'''       
