#normalizer.py : The main interface to normalize datas
#
# Copyright (C) 2011 University of Southern California.
# All rights reserved.
#
# Redistribution and use in source and binary forms are permitted
# provided that the above copyright notice and this paragraph are
# duplicated in all such forms and that any documentation, advertising
# materials, and other materials related to such distribution and use
# acknowledge that the software was developed by the University of
# Southern California, Information Sciences Institute.  The name of the
# University may not be used to endorse or promote products derived from
# this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED
# WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF
# MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#
# Author: Arun Viswanathan (aviswana@usc.edu)
#------------------------------------------------------------------------------
import sys
import os
import getopt

from plugin_base import BasicPlugin
from normalizerclass import Normalizer
VERSION = '0.1a'

def main():
    logfile =  '/var/log/syslog'
    outdb   = 'test.sqlite'
    
    try:
        opts, args = getopt.getopt(sys.argv[1:],
                                   '',
                                  ['input=', 'output=', 
                                   'ptype=',
                                   'verbose'])
    except getopt.error, msg:
        usage()
        sys.exit(2)

    # Set defaults for the command-line options
    input    = None
    output   = "default.sqlite"
    ptype    = None

    # Process options
    for option, arg in opts:
        if option == '--input':
          input = arg
        elif option == '--output':
          output = arg
        elif option == '--ptype':
          ptype = arg
        else:
            usage()
            sys.exit(2)
    
    
    if ((not input) or (not ptype)):
        usage()
        sys.exit(2)

    # Display program header
    header()
        
    if(not os.path.exists(input)):
        print "Input '%s' does not exist" % (input)
        sys.exit(2)

    if(os.path.exists(output)):
        print "Output file '%s' exists!" % (output)
 
  
    if(ptype == 'syslog'):
        mod = __import__('plugin_syslog', globals(), locals(), ['SyslogPlugin'])
        pluginclass = getattr(mod, 'SyslogPlugin')
    elif(ptype == 'apache'):
        mod = __import__('plugin_apache', globals(), locals(), ['ApachePlugin'])
        pluginclass = getattr(mod, 'ApachePlugin')
    elif(ptype == 'mysql'):
        mod = __import__('plugin_mysql', globals(), locals(), ['MySqlPlugin'])
        pluginclass = getattr(mod, 'MySqlPlugin')
    elif(ptype == 'bind'):
        mod = __import__('plugin_bindquery', globals(), locals(), ['BindQueryPlugin'])
        pluginclass = getattr(mod, 'BindQueryPlugin')
    else:
        print "Plugin type '%s' does not exist!" % (ptype)
        sys.exit(2)        
   
    plugin = pluginclass()
    n = Normalizer(input, output, plugin)
    n.run(plugin.get_processor())
    print n.get_stats()
    

def header():
    print """
#############################################
#    Raw Data to Events Normalizer - v%s  #
#############################################
""" % (VERSION)

def usage():
    header()
    print """
./normalize.py --input <inputfile>  --output  <outputfile> --ptype <plugintype>

Available plugin types
=======================
 syslog - for parsing syslog files
 apache - for parsing apache combined logs
 mysql  - for parsing mysql server logs
 bind   - for parsing bind query logs
"""

if __name__ == '__main__':
    main()
    
    
    