# plugin_base.py 
#
# Copyright (C) 2011 University of Southern California.
# All rights reserved.
#
# Redistribution and use in source and binary forms are permitted
# provided that the above copyright notice and this paragraph are
# duplicated in all such forms and that any documentation, advertising
# materials, and other materials related to such distribution and use
# acknowledge that the software was developed by the University of
# Southern California, Information Sciences Institute.  The name of the
# University may not be used to endorse or promote products derived from
# this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED
# WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF
# MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#
# Author: Arun Viswanathan (aviswana@usc.edu)
#------------------------------------------------------------------------------

import linecache
import time
import sys
from datetime import datetime
from datetime import tzinfo, timedelta, datetime
from simpleparse.parser import Parser

from attributes import Attributes
from normalizerclass import Normalizer
from recordparser import DefaultRecordParser

class BasicPlugin():
    """
        Basic plugin class provides a default implementation for all
        plugin related functions. 
    """
    
    def __init__(self):
        self.bnf = None
        self.production = None
        self.parser = Parser(self.get_ebnf(), self.get_production())
        self.rec_number = 1       

    def get_num_rawrecords(self):
        return self.rec_number

    def open(self, filename):
        self.logfile = filename
        handle = None
        return handle
        
    def get_next_record(self, handle):
       line = linecache.getline(self.logfile, self.rec_number)
       line = line.strip('\n')
       self.rec_number += 1
       return line
                    
    def parse(self, record, processor=None):
        print "Parsing %s" % (record)
        parsed_record = self.get_record_attrs(record)
        if not processor:
            processor = DefaultRecordParser(parsed_record)

        success, children, nextcharacter = self.parser.parse(record, 
                                                    processor=processor)
        if(not success):
            print "Unable to parse %s (%s chars parsed of %s),returned value was %s"%\
            ( repr(record), nextcharacter, len(record), 
              (success, children, nextcharacter))
            return None
            
        parsed_record.set_eventno(self.get_eventno(record))
        parsed_record.set_origin(self.get_origin(record))
        parsed_record.set_eventtype(self.get_eventtype(record))
        parsed_record.set_timestamp(self.get_timestamp(record, parsed_record))
        return parsed_record
    
    def get_processor(self):
        return None 

    def get_record_attrs(self, record):
        pass
    
    def get_eventno(self, record):
        pass

    def get_eventtype(self, record):
        pass

    def get_origin(self, record):
        pass

    def get_timestamp(self, record, parsed_record):
        return self._datetime_to_epoch(parsed_record.get_timeobj())        

    def close(self):
        pass
    
    def _datetime_to_epoch(self, timeobj):
        year = timeobj.get('year')
        month = timeobj.get('month')
        day = timeobj.get('day')
        hour = timeobj.get('hour')
        minute = timeobj.get('min')
        second = timeobj.get('sec')
        microsec = timeobj.get('microsec')
        tzinfo = timeobj.get('tzinfo')
        try:
            d = datetime(year, month, day, hour, minute, second, microsec, tzinfo)
        except Exception as ex:
            print "ERROR: '%s' while processing %s" %(ex, timeobj)
            sys.exit(2)
            
        return (int(time.mktime(d.timetuple())), 0)

