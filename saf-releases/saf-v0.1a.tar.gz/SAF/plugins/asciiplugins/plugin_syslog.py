# plugin_syslog.py - Plugin for syslog files
#
# Copyright (C) 2011 University of Southern California.
# All rights reserved.
#
# Redistribution and use in source and binary forms are permitted
# provided that the above copyright notice and this paragraph are
# duplicated in all such forms and that any documentation, advertising
# materials, and other materials related to such distribution and use
# acknowledge that the software was developed by the University of
# Southern California, Information Sciences Institute.  The name of the
# University may not be used to endorse or promote products derived from
# this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED
# WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF
# MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#
# Author: Arun Viswanathan (aviswana@usc.edu)
#------------------------------------------------------------------------------
from plugin_base import BasicPlugin
from attributes import Attributes
import commonterms

class SyslogPlugin(BasicPlugin):

    def init_plugin_attrs(self):
        self.attrs = Attributes()
        self.attrs.add('hostname', 'text')
        self.attrs.add('daemon', 'text')
        self.attrs.add('pid', 'text')
        self.attrs.add('charstring', 'text')
        return self.attrs
    
    def get_record_attrs(self, record):
        return self.attrs
    
    def get_eventtype(self, record=None):
        return "SYSLOG"
    
    def get_production(self):
        return "syslogrec"
  
    def get_ebnf(self):
        return self.syslogbnf

    syslogbnf = r'''#Comment
syslogrec := record
record    := timestamp, ts, message
message   := hostname, daemon, ('[', pid ,']')?, ':', charstring
hostname  := ts, [a-zA-Z0-9_.-]+
daemon    := ts, [a-zA-Z0-9_.-]+
pid       := ts, [0-9]+
charstring:= ts, -"\n"*
ts        :=  [ \t]*
'''       
